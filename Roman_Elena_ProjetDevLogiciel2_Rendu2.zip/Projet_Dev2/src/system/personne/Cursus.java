package system.personne;

public enum Cursus {
    E1,
    E2,
    E3,
    E4,
    E5
}
